export interface SearchCondition {
    field: string;
    value: string;
    comparison: string;
};
