
export interface TotalPrice {
    cp: number;
    sp: number;
    gp: number;
    pp: number;
}